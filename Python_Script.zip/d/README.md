<html>
<head>
</head>
<body>
<h1>.̶.͖̗̱̲͔̹͕̬͔͙̞͈̘̮͉́.̛͕̬͉̻͖͞͠.̟̬̩͖̠.̟̖̦͓͙̖͠..͇̭̼̼͇ͅ.̨͙̪̣̝̬̯͔͍͓̰̺̩̟̖.̹̥̘.͍̰̦̳̮͎̬͝.̸̲̤̗͓͈̜̦͓̪͓̯̘͔̹̰̀.̲̩͖̞̖̠̻̙̟͞.͡͡͠.̵̢͔̺͓̠̰̜̘͈̬͠.̨̹̳̪̮̯̜́̀ͅ.̡͕ͅ.̴͚̠̗̳̪͉̕ͅ.҉̖͙̣.̧̛̞̤̳͉͕͈̠̣͎̭͘.̴͔̙̮̺̖͉̤̙͚̟͔̘..̥̹̥̙̣̮̺̜̲̻̺̲̤͟͞.͘҉̜̘̳̫͖̩̮̠͕̻͇̰..̥͇̹͉̯̥̝̖̣̬̼͚ͅ.̰̱͕̟̰̙̳̮̜̹̰ͅ..̛̘͟͞ͅ.̥̞̥̻̣̮̮̭̤͈ͅ.̡̬̻̯͙̖̭͔̰͉̘͎̰́ͅ.͝.̶̶͉̪̬͖̯̱͍͓̞̘̰..̻̼͚̝.̠̩̲͍̮͇͖͠.̷̵̢̘̗̗̯̲͎.̨.̰̗͜͞.͔̪̠͔̹̫̟̰̪̝̥́́͡.͘͜.̛.͏͉͎͎͍͓̖̼͚̭͉.̻̱͈.̵̯̼͙͚͉̠̰͚̲́.̛̫͓͍̰̤̱̥̫̳̗̺̗̪̖͡.͇͉̳̹̩̮.̲̙͓̼.͇͔͠.̬̝.̢̺̞͟ͅ.̖͔̺̗̥̻̙̕͡.͘͝.̵̷̢̻̥̣͎ͅ.̷̬̱̻̫̩͚̳̪.͟.̖̻̫̠̠͖̩͕̼.̞̠̝̹̗̥̜̤̫̤͎̫͘ͅ.̧̻̙̙̹͉̹̠̬͙̭.̭̦̬̟̲͍̙͍͕̱̲̹.͜͞.̲̳͢͠.̹̪.͕͖͈̩͓̹.̵͇̹̘̘̭̲̱̟̗̘͈͡.̛͈͉..̸͏҉̪̘̦̗̮͔̲͉..͕.͚͕͖̩̳̲̟͈̝̩̦̮ͅ.̠͖̘͈ͅ.</h1>
</br>
<h1>[̲̅C̲̅][̲̅y̲̅][̲̅b̲̅][̲̅e̲̅][̲̅r̲̅] [̲̅T̲̅][̲̅K̲̅] [̲̅B̲̅][̲̅o̲̅][̲̅t̲̅] [̲̅C̲̅][̲̅o̲̅][̲̅n̲̅][̲̅t̲̅][̲̅r̲̅][̲̅o̲̅][̲̅l̲̅]</h1>
</br>
<h1>.̌ͨ̔̄.̛̎͌͂ͬ͊ͣ͗̑̈ͮͬͤ.̏̿̉̒ͭ̾̔́͛̀̇̓̃.͢.ͪ̉̓ͯ͌͐̎̈̌̐̾̒͒ͩ̚͜.͘.̇̀ͬ.ͬ̑ͩ̅̑́͆̑̕.ͤ̄̽̓̔͗ͦ̂͋̒ͬ.ͧ̊̇ͮ̊͛͑̂͗.̷̡͝.̾̓̎̽ͣͨ̿͌͆̚.̀́.̊͂̍͆͂.̴̍̇.͐̚.̸̾͊̈̄ͤ̓̄ͬ̅ͫͭ̚.͐͟.̍̎͆̏̚.̴̡̢́͋ͨ̿.̏ͣ̉͠..͗ͦ͂̐͐́͋ͬͯ҉҉͠.҉̡͜.ͬ͌̃̓̑͐̃̚.̸.̷̀͐̆̀͡...͐̓ͮͨ̉̀́.̡̨ͩͫ͊ͫͪ̄ͪͯ̈͟.̶ͮ̓̇̎ͦͩ̊ͦ͐ͥ̂̉͢͡.͒̃̐̚͜.̡.ͫ͊ͣ̿̿͆͆̇͊̿́͞͞.ͩ͑̑͒̓̐̎̉̅̓ͧ̏..̴̡̌̋ͯ͆ͪ̓̏̌ͥ͟..͛̈ͤͫͣ͊̋̈́̽̾ͮ̈́͌.ͤ̌ͪͨ̋̀́.̆͘.͡.̆ͭ̀͐͌͋̊ͣ̅͒ͩͦͬ̏.̌͑ͪ̐ͩͭ҉͝.̑̀̅̐̓̃̕.͘͢.̎̔͌ͫ̀͛ͪ̾.̛͋̿̑͊͛̒̂̌ͥ̃̈́̂͋ͤ.̷͛͐͑.̆̅̓̐̑̍̊ͨ̎ͦ̈́͆..ͮ̋́̋̀͊̊.̷̡̛̆̏̽̎̇̌̎ͮ͋ͬ̑̐̆.̌.ͬͨͩͩ̅̄̚..ͥͩ̔̐̓ͣ́͘͢.̡̢̀ͩ̂ͯ͊́͂̅́ͥͮ̃͑ͥ.ͤ̔͒ͦͮ҉.̵̸́͋ͮ̋̋̔͝.̡̢̑̅ͭͭ̑̈ͯ̉ͤ́ͣ̅ͮ̏ͪ͟.̸̈ͤ͜͡.̅̇́̌.̷͑͋̔̽ͬ̃́͋̉̀̅.̉̎̌ͥ̆ͭ͒ͪ͞.̎ͤ̄̃̌ͭ̅̀̕͡.͋͐ͧ̒̄ͪ͗̉̈̇̂̒̅̆͋.ͬͫ͑͂̈́́̂͊̒.̋͛ͪ͒̒̉̎̾̚.̛ͩͪ̉̉̆̏̎̽.͌̈́̓ͮ̓̀̚</h1>
</br>
<h1>.̶.͖̗̱̲͔̹͕̬͔͙̞͈̘̮͉́.̛͕̬͉̻͖͞͠.̟̬̩͖̠.̟̖̦͓͙̖͠..͇̭̼̼͇ͅ.̨͙̪̣̝̬̯͔͍͓̰̺̩̟̖.̹̥̘.͍̰̦̳̮͎̬͝.̸̲̤̗͓͈̜̦͓̪͓̯̘͔̹̰̀.̲̩͖̞̖̠̻̙̟͞.͡͡͠.̵̢͔̺͓̠̰̜̘͈̬͠.̨̹̳̪̮̯̜́̀ͅ.̡͕ͅ.̴͚̠̗̳̪͉̕ͅ.҉̖͙̣.̧̛̞̤̳͉͕͈̠̣͎̭͘.̴͔̙̮̺̖͉̤̙͚̟͔̘..̥̹̥̙̣̮̺̜̲̻̺̲̤͟͞.͘҉̜̘̳̫͖̩̮̠͕̻͇̰..̥͇̹͉̯̥̝̖̣̬̼͚ͅ.̰̱͕̟̰̙̳̮̜̹̰ͅ..̛̘͟͞ͅ.̥̞̥̻̣̮̮̭̤͈ͅ.̡̬̻̯͙̖̭͔̰͉̘͎̰́ͅ.͝.̶̶͉̪̬͖̯̱͍͓̞̘̰..̻̼͚̝.̠̩̲͍̮͇͖͠.̷̵̢̘̗̗̯̲͎.̨.̰̗͜͞.͔̪̠͔̹̫̟̰̪̝̥́́͡.͘͜.̛.͏͉͎͎͍͓̖̼͚̭͉.̻̱͈.̵̯̼͙͚͉̠̰͚̲́.̛̫͓͍̰̤̱̥̫̳̗̺̗̪̖͡.͇͉̳̹̩̮.̲̙͓̼.͇͔͠.̬̝.̢̺̞͟ͅ.̖͔̺̗̥̻̙̕͡.͘͝.̵̷̢̻̥̣͎ͅ.̷̬̱̻̫̩͚̳̪.͟.̖̻̫̠̠͖̩͕̼.̞̠̝̹̗̥̜̤̫̤͎̫͘ͅ.̧̻̙̙̹͉̹̠̬͙̭.̭̦̬̟̲͍̙͍͕̱̲̹.͜͞.̲̳͢͠.̹̪.͕͖͈̩͓̹.̵͇̹̘̘̭̲̱̟̗̘͈͡.̛͈͉..̸͏҉̪̘̦̗̮͔̲͉..͕.͚͕͖̩̳̲̟͈̝̩̦̮ͅ.̠͖̘͈ͅ.</h1>
</br>
<table border=5 width=50% cellpadding=5 cellspacing=5>
    <tr>
	  <h1> <th colspan=4>(O)╚══╝║♫ ♪ ♫ ♪▄ █ ▄ █ ▄ ▄ █ ▄ █ ▄ █ in- - - - - - - - - - - -●Max </th></h1>
    </tr>
</table>
</br>
<h1>.̌ͨ̔̄.̛̎͌͂ͬ͊ͣ͗̑̈ͮͬͤ.̏̿̉̒ͭ̾̔́͛̀̇̓̃.͢.ͪ̉̓ͯ͌͐̎̈̌̐̾̒͒ͩ̚͜.͘.̇̀ͬ.ͬ̑ͩ̅̑́͆̑̕.ͤ̄̽̓̔͗ͦ̂͋̒ͬ.ͧ̊̇ͮ̊͛͑̂͗.̷̡͝.̾̓̎̽ͣͨ̿͌͆̚.̀́.̊͂̍͆͂.̴̍̇.͐̚.̸̾͊̈̄ͤ̓̄ͬ̅ͫͭ̚.͐͟.̍̎͆̏̚.̴̡̢́͋ͨ̿.̏ͣ̉͠..͗ͦ͂̐͐́͋ͬͯ҉҉͠.҉̡͜.ͬ͌̃̓̑͐̃̚.̸.̷̀͐̆̀͡...͐̓ͮͨ̉̀́.̡̨ͩͫ͊ͫͪ̄ͪͯ̈͟.̶ͮ̓̇̎ͦͩ̊ͦ͐ͥ̂̉͢͡.͒̃̐̚͜.̡.ͫ͊ͣ̿̿͆͆̇͊̿́͞͞.ͩ͑̑͒̓̐̎̉̅̓ͧ̏..̴̡̌̋ͯ͆ͪ̓̏̌ͥ͟..͛̈ͤͫͣ͊̋̈́̽̾ͮ̈́͌.ͤ̌ͪͨ̋̀́.̆͘.͡.̆ͭ̀͐͌͋̊ͣ̅͒ͩͦͬ̏.̌͑ͪ̐ͩͭ҉͝.̑̀̅̐̓̃̕.͘͢.̎̔͌ͫ̀͛ͪ̾.̛͋̿̑͊͛̒̂̌ͥ̃̈́̂͋ͤ.̷͛͐͑.̆̅̓̐̑̍̊ͨ̎ͦ̈́͆..ͮ̋́̋̀͊̊.̷̡̛̆̏̽̎̇̌̎ͮ͋ͬ̑̐̆.̌.ͬͨͩͩ̅̄̚..ͥͩ̔̐̓ͣ́͘͢.̡̢̀ͩ̂ͯ͊́͂̅́ͥͮ̃͑ͥ.ͤ̔͒ͦͮ҉.̵̸́͋ͮ̋̋̔͝.̡̢̑̅ͭͭ̑̈ͯ̉ͤ́ͣ̅ͮ̏ͪ͟.̸̈ͤ͜͡.̅̇́̌.̷͑͋̔̽ͬ̃́͋̉̀̅.̉̎̌ͥ̆ͭ͒ͪ͞.̎ͤ̄̃̌ͭ̅̀̕͡.͋͐ͧ̒̄ͪ͗̉̈̇̂̒̅̆͋.ͬͫ͑͂̈́́̂͊̒.̋͛ͪ͒̒̉̎̾̚.̛ͩͪ̉̉̆̏̎̽.͌̈́̓ͮ̓̀̚</h1>
</br><b>✦    Continue To Follow Cyber-TK </b>
</br><b><h2>✦TKDDos One USE - Python 3 Python 3.5 And Linux Windows✦ </h2></b>
</br><b>✦    ============================================ </b>
</br><b>✦ 033[92m	TKDDos Dos Script v.1 https://github.com/CyberTKR/TKDDos-Python </b>
</br><b>✦ It is the end user's responsibility to obey all applicable laws. </b>
</br><b>✦ It is just for server testing script. Your ip is visible. </b>
</br><b>✦ usage : python3 TKDDos.py [-s] [-p] [-t] </b>
</br><b>✦ Windows: ./TKDDosTwo.py siteurl.com Or 125.124.21.25 (İp Adres) </b>
</br><b>✦ Linux: ./TKDDosTwo.py siteurl.com Or 125.124.21.25 (İp Adres) </b>
</br><b>✦ TKDDos [ -h ]: help </b>
</br><b>✦ TKDDos [ -s ]: server ip </b>
</br><b>✦ TKDDos [ -p ]: port default 80 </b>
</br><b>✦ TKDDos [-t ]: turbo default 135 \033[0m </b>
</br><b>✦    ============================================ </b>
</hr>
</br><b><h2>✦TKDDos Two USE - Python 2 - Python 2 x✦ </h2></b>
</br><b>✦    ============================================ </b>
</br><b>✦ Windows: TKDDosTwo.py http://www.siteurl.com/ </b>
</br><b>✦ Linux: python TKDDosTwo.py http://www.siteurl.com/ </b>
</br><b>✦    ============================================ </b>
</hr>
</br><b><h2>✦TKDDos Three USE -  Python 2 - Python 2 x✦ </h2></b>
</br><b>✦    ============================================ </b>
</br><b>✦ Windows: TKDDosThree.py http://www.siteurl.com/ </b>
</br><b>✦ Linux: python TKDDosThree.py http://www.siteurl.com/ </b>
</br><b>✦    ============================================ </b>
</hr>
</br><b><h2>✦TKDDos Four USE - Python 2 - Python 2 x✦ </h2></b>
</br><b>✦    ============================================ </b>
</br><b>✦    Usage: python TKDDosFour.py http://www.example.com/ </b>
 </br><b>✦   ============================================ </b>
<b><hr/></b>
<h2><b> Official Account's </b></h2>
</br><b>✦  Line Contact ✔⇩ </b>
</br><b>✦  cybertk0  </b>
</br><b>✦ ⇩Add⇩Line⇩ </b>
<p><a href="https://line.me/R/ti/p/~cybertk0" rel="nofollow"><img height="36" border="0" alt="Add Friend" src="https://camo.githubusercontent.com/035d0206e65dfbdfb7cdabbd6f5a1f4fb59f0e41/68747470733a2f2f7363646e2e6c696e652d617070732e636f6d2f6e2f6c696e655f6164645f667269656e64732f62746e2f656e2e706e67" data-canonical-src="https://scdn.line-apps.com/n/line_add_friends/btn/en.png" style="max-width:100%;"></a></p>
</br><b>✦    CyberTKDDos </b>
</br><b>✦    Cybertk DDos scripti'dir. </b>
</br><b>✦    Gelişim amacli kullanilmalidir. </b>
</br><b>✦    Baska herhangi bir amacla kullanilmak icin duzenlenmesinden ve, </b>
</br><b>✦    kullanilmasindan cybertk sorumlu degildir. </b>
<br/><b>✦ İnstagram Account ➥<a href="http://instagram.com/_aquariusman " title="Tolga instagram Account"> _aquariusman </a> </b>
<br/><b>✦Youtube Channel ➥<a href="https://youtube.com/channel/UC9AyYKWovERexyOFy3h4rdw" title="CyberTK Youtube Channel"> CyberTK Official Channel </a></b>
</br>
</br>
<br/><b>✦<a href="mailto:tolgajames2@gmail.com">To send a mail, just click,<b> </a>
</br><p><b>✦<a href="mailto:tolgajames2@gmail.com">On the Mail Icon below.↴⇩<b> </a></p>
</br><a href="mailto:tolgajames2@gmail.com"> <img src="https://github.com/CyberTKR/CyberJS/blob/master/CyberJS/curve-thrift/mail.png" width=100/></a>
</br>
</br>
</body>
 </html>
